#region Library
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
#endregion Library

#region NameSpace
namespace FlightBookingWebApi
{
    #region Class
    public class Program
    {
        // Applications Execution Starts From Here
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        // Hosting Server
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
    #endregion Class
}
#endregion NameSpace
