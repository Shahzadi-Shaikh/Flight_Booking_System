﻿#region Library
using System.ComponentModel.DataAnnotations;
#endregion Library

#region NameSpace
namespace FlightBookingWebApi.Models
{
	#region Class
	public class FBS_Booking_Transaction
    {
		[Key]

        #region FBS_Booking_Transaction
        public int FBS_Reference_Id { get; set; }
		public int FBS_Flight_Id { get; set; }
		public string Cust_First_Name { get; set; }
		public string Cust_Last_Name { get; set; }
		public string Cust_EmailId { get; set; }
		public string Cust_Contact_No { get; set; }

        #endregion FBS_Booking Transaction
    }
    #endregion Class
}
#endregion NameSpace
