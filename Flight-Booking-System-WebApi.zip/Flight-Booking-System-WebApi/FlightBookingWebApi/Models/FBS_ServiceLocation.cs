﻿#region Library
using System.ComponentModel.DataAnnotations;
#endregion Library

#region NameSpace
namespace FlightBookingWebApi.Models
{
    #region Class
    public class FBS_ServiceLocation
    {
        #region Table
        public int FBS_ServiceLocation_Id { get; set; }
        [Key]
        public string FBS_LocationName { get; set; }

        #endregion Table
    }
    #endregion Class
}
#endregion NameSpace
