﻿#region Library
using System;
using System.ComponentModel.DataAnnotations;
#endregion Library

#region NameSpace
namespace FlightBookingWebApi.Models
{
    #region Class
    public class FBS_Flight_Master
    {
        [Key]

        #region Table
        public int FBS_Flight_Id { get; set; }
        public string FBS_Flight_Origin { get; set; }
        public string FBS_Flight_Destination { get; set; }
        public DateTime FBS_Flight_DateTime { get; set; }
        public int FBS_Flight_Fare { get; set; }

        #endregion Table
    }
    #endregion Class
}
#endregion NameSpace
