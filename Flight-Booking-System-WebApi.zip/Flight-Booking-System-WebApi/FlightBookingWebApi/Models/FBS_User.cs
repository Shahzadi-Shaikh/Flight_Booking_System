﻿#region Library
using System.ComponentModel.DataAnnotations;
#endregion Library

#region NameSpace
namespace FlightBookingWebApi.Models
{
    #region Class
    public class FBS_User
    {
        [Key]

        #region FBS_User Table
        public int Id { get; set; }
        public string Name { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        #endregion FBS_User Table
    }
    #endregion Class
}
#endregion NameSpace
