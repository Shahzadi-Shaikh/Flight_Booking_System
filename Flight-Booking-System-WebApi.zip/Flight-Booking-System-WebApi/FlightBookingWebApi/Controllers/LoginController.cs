﻿#region Library
using System.Linq;
using FlightBookingWebApi.Data;
using FlightBookingWebApi.Models;
using Microsoft.AspNetCore.Mvc;
#endregion Library

#region NameSpace
namespace FlightBookingWebApi.Controllers
{
    #region Api Attribute
    [Route("api/[controller]")]
    [ApiController]
    #endregion Api Attribute

    #region Login Controller Class
    public class LoginController : ControllerBase
    {
       // Object Created of UserDb Context Class
        private readonly UserDbContext context;
        public LoginController(UserDbContext _context)
        {
            context = _context;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>

        #region Users
        [HttpGet("Users")]
        public IActionResult GetUsers()
        {
            var userDetails = context.Users.AsQueryable();
            return Ok(userDetails);
        }
        #endregion Users

        /// <summary>
        /// This method is use to login
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
       
        #region Login
        [HttpPost("Login")]
        public IActionResult Login([FromBody] FBS_User obj)
        {
            if (obj == null)
            {
                return BadRequest();
            }
            else
            {
                var user = context.Users.Where(a =>
                a.Username == obj.Username
                && a.Password == obj.Password).FirstOrDefault();
                if (user != null)
                {
                    return Ok(new
                    {
                        StatusCode = 200,
                        Message = " Logged in Successfully"
                    });
                }
                else
                {
                    return NotFound(new
                    {
                        StatusCode = 404,
                        Message = "User Not Found"
                    });
                }
            }
        }
        #endregion Login
    }
    #endregion Login Controller Class
}
#endregion NameSpace
