﻿#region Library
using FlightBookingWebApi.Models;
using Microsoft.EntityFrameworkCore;
#endregion Library

#region NameSpace
namespace FlightBookingWebApi.Data
{
    #region Class
    public class UserDbContext : DbContext
    {
        public UserDbContext(DbContextOptions<UserDbContext> options) : base(options)
        {

        }

        #region Data base tables
        public DbSet<FBS_User> Users { get; set; }
        public DbSet<FBS_Flight_Master> fBS_Flight_Masters { get; set; }
        public DbSet<FBS_ServiceLocation> FBS_ServiceLocations { get; set; }
        public DbSet<FBS_Booking_Transaction> FBS_Booking_Transactions { get; set; }

        #endregion Data base tables
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            /// <Summary>
            /// Principle Entities are define here 
            /// </Summary>

            modelBuilder.Entity<FBS_User>().ToTable("FBS_User");
            modelBuilder.Entity<FBS_Flight_Master>().ToTable("FBS_Flight_Master");
            modelBuilder.Entity<FBS_ServiceLocation>().ToTable("FBS_ServiceLocation");
            modelBuilder.Entity<FBS_Booking_Transaction>().ToTable("FBS_Booking_Transaction");

        }
    }
    #endregion Class
}
#endregion NameSpace