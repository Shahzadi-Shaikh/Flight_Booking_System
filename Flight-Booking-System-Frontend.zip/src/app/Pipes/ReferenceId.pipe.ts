import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'ReferenceId'
})
export class ReferenceIdPipe implements PipeTransform {

  transform(value: any,ReferenceIdFilter : string ):any {
    if(!value) return null;
    if(!ReferenceIdFilter) return value;
    ReferenceIdFilter = ReferenceIdFilter.toLowerCase();
    return value.filter((f:any) => JSON.stringify(f).toLocaleLowerCase().includes(ReferenceIdFilter))
  }

}
