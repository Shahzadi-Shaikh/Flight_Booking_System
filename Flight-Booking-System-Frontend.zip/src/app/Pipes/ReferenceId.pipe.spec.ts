import {ReferenceIdPipe} from './ReferenceId.pipe'
describe('ReferenceIdPipe', () => {
  it('create an instance', () => {
    const pipe = new ReferenceIdPipe();
    expect(pipe).toBeTruthy();
  });
});
