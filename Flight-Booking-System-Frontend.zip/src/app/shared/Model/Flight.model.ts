
export class Flight
{
    "FBS_Flight_Id" : Number;
    "FBS_Flight_Origin": String;
    "FBS_Flight_Destination" : String;
    "FBS_Flight_DateTime" : Date;
    "FBS_Flight_Fare": Number;
}