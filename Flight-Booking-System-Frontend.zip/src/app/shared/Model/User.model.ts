export class UserModel
{
    "Id" : Number;
    "Name" : String;
    "Username" : String;
    "Password" :String;
}