export class Booking 
{
    "FBS_Booking_Id" : Number;
    "FBS_Flight_Id" : Number;
    "Cust_First_Name" : String;
    "Cust_Last_Name" : String;
    "Cust_EmailId" : String;
    "Cust_Contact_No" : Number;
      value: any;
}